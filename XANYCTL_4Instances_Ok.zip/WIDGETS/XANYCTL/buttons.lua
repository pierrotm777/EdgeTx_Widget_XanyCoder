-- XANYCTL - UI libGUI (boutons + slider PROP)
-- Ce fichier ne contient que l'interface graphique et les interactions tactiles.
-- Il reçoit :
--   zone, options, config, api
-- et renvoie un objet widget avec méthodes refresh/update/background.
--
-- IMPORTANT :
--   - On dessine toujours dans zone (pas de coordonnées 480x272 "en dur").
--   - On ne bloque pas le bouton RET : on ne consomme pas EVT_EXIT_BREAK.

local zone, options, config, api = ...
local widget = {}
widget.options = options
widget.config = config or {}
widget.api = api or {}


-- --------------------------------------------------------------------------
-- Couleurs personnalisables (options du widget)
--   OffCol / OnCol : index 0..7 dans une petite palette basée sur COLOR_THEME_*
-- IMPORTANT:
--   - On reste sur les couleurs "theme" EdgeTX pour garder une bonne lisibilité.
--   - Si une option n'est pas disponible (ancien modèle), on retombe sur les couleurs par défaut.
-- --------------------------------------------------------------------------

-- --------------------------------------------------------------------------
-- Couleurs configurables depuis les options du widget
-- --------------------------------------------------------------------------
-- --------------------------------------------------------------------------
-- Ombres (optionnelles)
-- --------------------------------------------------------------------------
local function isShadowEnabled()
  -- BOOL option : true/false (selon EdgeTX)
  return widget.options and widget.options.Shadow
end

local function getOffOnColors()
  local offCol = (widget.options and widget.options.OffCol) or COLOR_THEME_SECONDARY1
  local onCol  = (widget.options and widget.options.OnCol)  or COLOR_THEME_PRIMARY2
  return offCol, onCol
end

local libGUI_chunk
local libGUI
local gui

-- --------------------------------------------------------------------------
-- Chargement libGUI (pattern Multiswitch)
-- --------------------------------------------------------------------------
local function loadGUI()
  if not libGUI then
    if not libGUI_chunk then
      libGUI_chunk = loadScript("/WIDGETS/LibGUI/libgui.lua")
    end
    if libGUI_chunk then
      libGUI = libGUI_chunk()
    end
  end
  return libGUI
end

-- --------------------------------------------------------------------------
-- Helpers d'affichage : rectangle arrondi (fallback si non dispo)
-- --------------------------------------------------------------------------
local function drawRoundRect(gui, x, y, w, h, color, radius)
  radius = radius or 14

  -- certains libGUI exposent drawFilledRoundRect(gui, x,y,w,h,color,r)
  if libGUI and type(libGUI.drawFilledRoundRect) == "function" then
    return libGUI.drawFilledRoundRect(gui, x, y, w, h, color, radius)
  end
  -- d'autres exposent gui.drawFilledRoundRect(...)
  if gui and type(gui.drawFilledRoundRect) == "function" then
    return gui.drawFilledRoundRect(x, y, w, h, color, radius)
  end

  -- fallback : rectangle classique
  if gui and type(gui.drawFilledRectangle) == "function" then
    return gui.drawFilledRectangle(x, y, w, h, color)
  end
end
-- --------------------------------------------------------------------------
-- drawShadowedRoundRect()
--   Dessine un rectangle arrondi avec une ombre douce (optionnelle).
--   L'ombre est simulée par 1 à 2 rectangles décalés (sans alpha, compatible EdgeTX).
-- --------------------------------------------------------------------------
local function drawShadowedRoundRect(gui, x, y, w, h, fillColor, radius)
  radius = radius or 14
  if isShadowEnabled() then
    -- Ombre douce: 2 passes décalées
    drawRoundRect(gui, x + 2, y + 2, w, h, COLOR_THEME_SECONDARY2, radius)
    drawRoundRect(gui, x + 1, y + 1, w, h, COLOR_THEME_SECONDARY3, radius)
  end
  drawRoundRect(gui, x, y, w, h, fillColor, radius)
end



-- --------------------------------------------------------------------------
-- Mode -> (nb boutons, présence PROP)
-- --------------------------------------------------------------------------
local function modeToLayout(mode)
  local nbtn = (mode == 0 or mode == 1) and 8 or 16
  local hasProp = (mode == 1 or mode == 3)
  return nbtn, hasProp
end

-- --------------------------------------------------------------------------
-- Construit GUI + contrôles
-- --------------------------------------------------------------------------
local controls = {}
local currentLayoutKey = nil

local function initGUI()
  local lg = loadGUI()
  if not lg then return nil end
  gui = lg.newGUI()
  return gui
end

-- Bouton toggle (ON/OFF)
local function makeToggleButton(x, y, w, h, idx, label, radius)
  local self = {
    idx = idx,
    label = label or tostring(idx),
    radius = radius or 14,
    disabled = false,
    hidden = false,
  }

  function self.draw(focused)
    local v = widget.api.gv_get(idx, 0)
    local offCol, onCol = getOffOnColors()
    local bg = (v ~= 0) and onCol or offCol
    local fg = (v ~= 0) and COLOR_THEME_PRIMARY3 or COLOR_THEME_SECONDARY3
    local br = focused and COLOR_THEME_FOCUS or COLOR_THEME_SECONDARY2

    drawShadowedRoundRect(gui, x, y, w, h, bg, self.radius)
    gui.drawRectangle(x, y, w, h, br)

    gui.drawText(x + w/2, y + h/2, self.label, CENTER + VCENTER + fg)
  end

  function self.onEvent(event, touchState)
    if event == EVT_VIRTUAL_ENTER then
      local v = widget.api.gv_get(idx, 0)
      widget.api.gv_set(idx, (v == 0) and 1 or 0)
    end
  end

  gui.custom(self, x, y, w, h)
  return self
end

-- Bouton momentané (ON tant qu'on appuie)
local function makeMomentaryButton(x, y, w, h, idx, label, radius)
  local self = {
    idx = idx,
    label = label or tostring(idx),
    radius = radius or 14,
    disabled = false,
    hidden = false,
    value = false,
  }

  function self.draw(focused)
    local v = widget.api.gv_get(idx, 0)
    local offCol, onCol = getOffOnColors()
    local bg = (v ~= 0) and onCol or offCol
    local fg = (v ~= 0) and COLOR_THEME_PRIMARY3 or COLOR_THEME_SECONDARY3
    local br = focused and COLOR_THEME_FOCUS or COLOR_THEME_SECONDARY2

    drawShadowedRoundRect(gui, x, y, w, h, bg, self.radius)
    gui.drawRectangle(x, y, w, h, br)
    gui.drawText(x + w/2, y + h/2, self.label, CENTER + VCENTER + fg)
  end

  function self.onEvent(event, touchState)
    -- tactile : press -> ON / release -> OFF
    if event == EVT_TOUCH_FIRST then
      if self.covers(touchState.x, touchState.y) then
        gui.editing = true
        widget.api.gv_set(idx, 1)
      end
    elseif event == EVT_TOUCH_BREAK or event == EVT_VIRTUAL_EXIT then
      if gui.editing then
        gui.editing = false
        widget.api.gv_set(idx, 0)
      end
    elseif event == EVT_VIRTUAL_ENTER_LONG then
      gui.editing = true
      widget.api.gv_set(idx, 1)
    end
  end

  gui.custom(self, x, y, w, h)
  return self
end

-- Slider vertical PROP (0..255) - uniquement modes +PROP
local function makePropSlider(x, y, w, h, label)
  local self = {
    x=x,y=y,w=w,h=h,
    label = label or "PROP",
    min = 0,
    max = 255,
    value = widget.api.gv_get(17, 0),
    delta = 1,
    disabled = false,
    hidden = false,
    editable = true,
  }

  function self.draw(focused)
    local v = widget.api.gv_get(17, 0)
    self.value = v

    -- rail
    -- MODIF UI:
    --   Fond du slider identique aux boutons (rectangle arrondi + bordure).
    local offCol, onCol = getOffOnColors()
    local bg = offCol
    local br = focused and COLOR_THEME_FOCUS or COLOR_THEME_SECONDARY2
    drawShadowedRoundRect(gui, x, y, w, h, bg, 14)
    gui.drawRectangle(x, y, w, h, br)

    local ydot = y + h - (h * (v - self.min) / (self.max - self.min))
    ydot = math.max(y, math.min(y + h, ydot))

    -- "tige" + curseur
    gui.drawFilledRectangle(x + w/2 - 2, y + 4, 4, h - 8, COLOR_THEME_PRIMARY1)
    
    -- MODIF UI: curseur oblong large (presque largeur du slider)
    local knobW = w - 6
    local knobH = 14
    local kx = x + (w - knobW) / 2
    local ky = ydot - knobH/2
    drawShadowedRoundRect(gui, kx, ky, knobW, knobH, onCol, 7)

    -- Affiche la valeur PROP en pourcentage (0..100%)
    local pct = math.floor(((v - self.min) * 100 / (self.max - self.min)) + 0.5)
    gui.drawText(x + w/2, y - 14, string.format("%s %d%%", self.label, pct), SMLSIZE + CENTER + COLOR_THEME_SECONDARY3)
  end

  function self.onEvent(event, touchState)
    if event == EVT_TOUCH_SLIDE then
      if self.covers(touchState.x, touchState.y) then
        local v = self.min + (self.max - self.min) * (y + h - touchState.y) / h
        v = math.floor(math.max(self.min, math.min(self.max, v)) + 0.5)
        widget.api.gv_set(17, v)
      end
    elseif event == EVT_VIRTUAL_INC then
      widget.api.gv_set(17, math.min(self.max, widget.api.gv_get(17,0) + self.delta))
    elseif event == EVT_VIRTUAL_DEC then
      widget.api.gv_set(17, math.max(self.min, widget.api.gv_get(17,0) - self.delta))
    end
  end

  gui.custom(self, x, y, w, h)
  return self
end


-- --------------------------------------------------------------------------
-- resetGUI() :
--   Certaines versions de libGUI n'ont pas gui.reset().
--   On tente plusieurs méthodes, sinon on recrée l'objet GUI.
-- --------------------------------------------------------------------------
local function resetGUI()
  if not gui then return end
  if type(gui.reset) == "function" then
    resetGUI()
    return
  end
  if type(gui.clear) == "function" then
    gui.clear()
    return
  end
  if type(gui.resetAll) == "function" then
    gui.resetAll()
    return
  end
  -- Fallback universel : recréer un nouvel objet GUI
  local lg = loadGUI()
  if lg and type(lg.newGUI) == "function" then
    gui = lg.newGUI()
  end
end

-- --------------------------------------------------------------------------
-- (Re)build layout selon MODE
-- --------------------------------------------------------------------------
local function buildLayout()
  if not gui then
    if not initGUI() then return end
  end

  controls = {}
  resetGUI()

  local mode = (widget.options and widget.options.MODE) or 0
  local ch   = (widget.options and widget.options.CH) or 8
  local rep  = (widget.options and widget.options.Repeat) or 0

  -- synchronisation "info" dans GVars (utile à xanytx.lua)
  widget.api.gv_set(32, mode)
  widget.api.gv_set(31, ch)
  widget.api.gv_set(18, rep)

  local nbtn, hasProp = modeToLayout(mode)
  local cols = 4
  local rows = (nbtn == 8) and 2 or 4

  local headerH = 28
  local pad = 6
  local sliderW = hasProp and 58 or 0
  local gridW = zone.w - pad*2 - sliderW - (hasProp and pad or 0)
  local gridH = zone.h - headerH - pad*2

  local cellW = math.floor(gridW / cols)
  local cellH = math.floor(gridH / rows)

  local x0 = zone.x + pad
  local y0 = zone.y + headerH + pad

  -- Boutons
  for i=1,nbtn do
    local cfg = (widget.config.buttons and widget.config.buttons[i]) or {}
    local label = cfg.label or tostring(i)
    local typ = cfg.type or "toggle"

    local r = math.floor((i-1)/cols)
    local c = (i-1)%cols
    local x = x0 + c*cellW
    local y = y0 + r*cellH
    local w = cellW - 6
    local h = cellH - 6

    local b
    if typ == "momentary" then
      b = makeMomentaryButton(x, y, w, h, i, label, 10)
    else
      b = makeToggleButton(x, y, w, h, i, label, 10)
    end
    controls[#controls+1] = b
  end

  -- Slider PROP
  if hasProp then
    local sx = x0 + gridW + pad
    local sy = y0
    local sh = gridH
    local slabel = (widget.config.prop and widget.config.prop.label) or "PROP"
    controls[#controls+1] = makePropSlider(sx, sy, sliderW, sh, slabel)
  end

  currentLayoutKey = tostring(mode).."_"..tostring(zone.w).."x"..tostring(zone.h)
end

-- --------------------------------------------------------------------------
-- widget.update() : rebuild si nécessaire
-- --------------------------------------------------------------------------
function widget:update()
  currentLayoutKey = nil
end

-- --------------------------------------------------------------------------
-- widget.refresh() : header + GUI
-- --------------------------------------------------------------------------
function widget:refresh(event, touchState)
  if not gui then
    if not initGUI() then
      lcd.drawText(zone.x+2, zone.y+2, "LibGUI absente", SMLSIZE)
      return
    end
  end

  local mode = (self.options and self.options.MODE) or 0
  local ch   = (self.options and self.options.CH) or 8
  local rep  = (self.options and self.options.Repeat) or 0

  local key = tostring(mode).."_"..tostring(zone.w).."x"..tostring(zone.h)
  if currentLayoutKey ~= key then
    buildLayout()
  end

  -- Header
  local nbtn, hasProp = modeToLayout(mode)
  local title = "XANYCTL"
  local line2 = "CH"..tostring(ch).."  MODE "..tostring(mode).." (SW"..tostring(nbtn)..")"..(hasProp and "+PROP" or "").."  REPEAT "..tostring(rep)

  lcd.drawText(zone.x + 2, zone.y + 1, title, BOLD)
  lcd.drawText(zone.x + 2, zone.y + 16, line2, SMLSIZE)

  -- GUI : on laisse EVT_EXIT_BREAK à EdgeTX (RET)
  gui.run(event, touchState)
end

function widget:background()
  -- rien pour l'instant
end

return widget