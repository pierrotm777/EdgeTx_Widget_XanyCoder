# XANYCTL - 4 instances using Flight Modes (FM banks)

This build stores 4 independent X-Any states in the model's GVars *per Flight Mode*:

- Widget option **ID=1** -> reads/writes **FM0** GVar bank
- **ID=2** -> **FM1**
- **ID=3** -> **FM2**
- **ID=4** -> **FM3**

The MIX scripts `xanytx1.lua .. xanytx4.lua` read from the matching FM bank, **without changing the active flight mode**.

## Notes
- No SD writes (no state.txt/state.lua).
- Requires the EdgeTX API `model.getGlobalVariable(idx, fm)` / `model.setGlobalVariable(idx, fm, value)`.
