-- XANYCTL - Widget principal
-- EdgeTX 2.11+ / TX16S (tactile)
--
-- Objectif actuel :
--   - SW8 / SW8+PROP / SW16 / SW16+PROP
--   - trame X-Any générée côté MIXES/xanytx.lua (script de mix)
--   - le widget ne fait que piloter des "GV virtuelles" packées dans GV1..GV6
--
-- PACK GVars (vrai modèle EdgeTX : GV1..GV9 max) :
--   GV1 + GV2 : mask 16 bits (boutons 1..16)
--              GV1 = partie basse (0..2047)
--              GV2 = partie haute (0..31) -> mask = GV1 + GV2*2048
--   GV3       : Repeat (0..6)  (Repeat+1 symboles identiques si besoin)
--   GV4       : MODE stored in GV4 as 0..4
--              Widget option MODE now uses CHOICE.
--              On this project/radio, CHOICE returns 1..5, so we convert it
--              back to 0..4 before storing it in GV4.
--   GV5       : CH mémo (info confort ; la vraie voie est celle où tu mixes la sortie LUA)
--   GV7       : PROP (0..255) (utilisé uniquement en modes +PROP / ANGLE+PROP)
--   GV8       : ANGLE (0..359°) utilisé en mode ANGLE+PROP
--
-- IMPORTANT :
--   - Dans un WIDGET, EdgeTX ne fournit pas gv_get/gv_set globalement.
--     On fournit ici des wrappers compatibles via model.getGlobalVariable()/setGlobalVariable().
--   - Les accents sont en UTF-8 (é, è, à…).

local name = "XANYCTL"

local languagePath

-- --------------------------------------------------------------------------
-- Extract language from wgt.options.Language
-- --------------------------------------------------------------------------
local function getLanguageCode(wgt)
  local idx = (wgt.options and wgt.options.Language) or 1
  local langs = { "cn", "de", "en", "fr", "it", "sp" }
  return langs[idx] or "fr"
end

-- --------------------------------------------------------------------------
-- Read text file on sd card
-- --------------------------------------------------------------------------
local function readTextFile(path)
  local f = io.open(path, "r")
  if not f then
    return nil
  end

  local txt = io.read(f, 128)
  io.close(f)

  return txt
end

-- --------------------------------------------------------------------------
-- Copy TEMPLATE.lua -> <ModelName>.lua if missing
-- --------------------------------------------------------------------------
local function createModelConfig(modelName)
  local srcPath = "/WIDGETS/" .. name .. "/TEMPLATE.lua"
  local dstPath = "/WIDGETS/" .. name .. "/" .. modelName .. ".lua"

  local fcheck = io.open(dstPath, "r")
  if fcheck then
    io.close(fcheck)
    return true
  end

  local fsrc = io.open(srcPath, "r")
  if not fsrc then
    return false
  end

  local content = io.read(fsrc, 32768)
  io.close(fsrc)

  if not content or content == "" then
    return false
  end

  local fdst = io.open(dstPath, "w")
  if not fdst then
    return false
  end

  io.write(fdst, content)
  io.close(fdst)

  return true
end


-- --------------------------------------------------------------------------
-- Build localized "model config missing -> TEMPLATE added" warning
-- Language file may contain one line or two lines separated with \n.
-- %s is replaced by "<ModelName>.lua".
-- --------------------------------------------------------------------------
local function buildNoConfigWarning(wgt, modelName)
  local langCode = getLanguageCode(wgt)
  local filePath = "/WIDGETS/XANYCTL/Languages/" .. langCode .. "/Warning_NoConfigFile.txt"

  local txt = readTextFile(filePath)
  local modelFile = modelName .. ".lua"

  if txt == nil then
    txt = ""
  else
    txt = tostring(txt)
  end

  if txt == "" then
    txt = "%s not found\n%s has been added"
  end

  -- Language file stores "\n" as text; convert it to a real line break.
  txt = string.gsub(txt, "\\n", string.char(10))

  -- Replace up to 2 placeholders with the model file name.
  txt = string.gsub(txt, "%%s", modelFile, 1)
  txt = string.gsub(txt, "%%s", modelFile, 1)

  return txt
end

-- --------------------------------------------------------------------------
-- EdgeTX version check
--
-- This widget requires EdgeTX >= 2.11:
--   - CHOICE widget option type
--   - >5 options support
-- --------------------------------------------------------------------------
local ver, radio, maj, minor, rev, osname = getVersion()
local os1 = string.format("%d.%d", maj, minor)

local EDGE_MIN_OK = false
if maj > 2 then
  EDGE_MIN_OK = true
elseif maj == 2 and minor >= 11 then
  EDGE_MIN_OK = true
end

-- --------------------------------------------------------------------------
-- Multi-instance via Flight Modes (FM banks)
--
-- We keep the original "1-instance" philosophy (GV1..GV6 mapping) but we store
-- 4 independent banks in the model's Flight Modes:
--   ID=1 -> FM0, ID=2 -> FM1, ID=3 -> FM2, ID=4 -> FM3
--
-- Advantages:
--   - No SD writes
--   - Very reliable and fast
--
-- NOTE:
--   This uses model.getGlobalVariable()/setGlobalVariable() with a flight mode
--   parameter. It does NOT change your active flight mode; it only selects the
--   GV bank to read/write.
-- --------------------------------------------------------------------------
local function getFM(options)
  local id = (options and options.ID) or 1
  id = tonumber(id) or 1
  if id < 1 then id = 1 end
  if id > 4 then id = 4 end
  return id - 1 -- FM0..FM3
end

-- --------------------------------------------------------------------------
-- Runtime context used by gv_get/gv_set
--
-- gv_get()/gv_set() are called by buttons.lua through the API table and do not
-- receive the widget instance directly. We therefore keep the "current options"
-- here so the correct FM bank is always used.
-- --------------------------------------------------------------------------
local currentOptions = nil

-- --------------------------------------------------------------------------
-- Temporary warning overlay
--
-- If the model-specific config file is missing or invalid, we fall back to
-- TEMPLATE.lua and show a centered red warning with dark grey shadow for 3s.
-- --------------------------------------------------------------------------
local warningText = nil
local warningUntil = 0

-- --------------------------------------------------------------------------
-- normalizeModeChoice()
--
-- MODE comes back as 1..5 with CHOICE in this project/radio:
--   1 = SW8
--   2 = SW8+PROP
--   3 = SW16
--   4 = SW16+PROP
--   5 = ANGLE+PROP

-- The X-Any encoder always expects 0..4 stored in GV4:
--   0 = SW8
--   1 = SW8+PROP
--   2 = SW16
--   3 = SW16+PROP
--   4 = ANGLE+PROP
-- --------------------------------------------------------------------------
local function normalizeModeChoice(v)
  v = tonumber(v) or 1
  if v < 1 then v = 1 end
  if v > 5 then v = 5 end
  return v - 1
end

-- --------------------------------------------------------------------------
-- deepCopy()
-- Used so each widget instance gets its own config table.
-- This avoids accidental sharing between widgets.
-- --------------------------------------------------------------------------
local function deepCopy(src)
  if type(src) ~= "table" then
    return src
  end

  local dst = {}
  for k, v in pairs(src) do
    dst[k] = deepCopy(v)
  end
  return dst
end

-- --------------------------------------------------------------------------
-- selectInstanceConfig()
--
-- Supports:
--   - old 1-instance format
--   - new 4-instance format with cfg.instances[1..4]
--
-- Returns a deep copy so each widget has its own independent labels/config.
-- --------------------------------------------------------------------------
local function selectInstanceConfig(cfg, options)
  if type(cfg) ~= "table" then
    return nil
  end

  local id = (options and options.ID) or 1
  id = tonumber(id) or 1
  if id < 1 then id = 1 end
  if id > 4 then id = 4 end

  if type(cfg.instances) == "table" and type(cfg.instances[id]) == "table" then
    return deepCopy(cfg.instances[id])
  end

  return deepCopy(cfg)
end

-- --------------------------------------------------------------------------
-- Chargement config par modèle (fichier à côté du widget)
--
-- Priorité :
--   1) /WIDGETS/XANYCTL/<NomDuModele>.lua
--   2) /WIDGETS/XANYCTL/TEMPLATE.lua
--
-- Si le fichier modèle n'existe pas ou est invalide, TEMPLATE.lua est chargé
-- et un message d'avertissement temporaire est affiché.
--
-- Nouveau format 4 instances supporté :
--
--   return {
--     instances = {
--       [1] = { buttons = {...}, prop = {...} },
--       [2] = { buttons = {...}, prop = {...} },
--       [3] = { buttons = {...}, prop = {...} },
--       [4] = { buttons = {...}, prop = {...} },
--     }
--   }
--
-- Ancien format 1-instance toujours accepté :
--
--   return {
--     buttons = {...},
--     prop = {...}
--   }
-- --------------------------------------------------------------------------
local function loadModelConfig()
  local mi = model.getInfo()
  local modelName = mi.name

  local try = {
    "/WIDGETS/"..name.."/"..modelName..".lua",
    "/WIDGETS/"..name.."/TEMPLATE.lua",
  }

  local usedTemplate = false
  local cfg = nil

  --------------------------------------------------------------------------
  -- Try model file first, then TEMPLATE.lua
  --------------------------------------------------------------------------
  for i, p in ipairs(try) do
    local chunk = loadScript(p)
    if chunk then
      local ok, loaded = pcall(chunk)

      if ok and type(loaded) == "table" then
        cfg = loaded
      elseif ok and type(loaded) == "function" then
        local ok2, loaded2 = pcall(loaded)
        if ok2 and type(loaded2) == "table" then
          cfg = loaded2
        end
      end

      if cfg then
        if i == 2 and warningText == nil then
          warningText = buildNoConfigWarning({ options = currentOptions }, modelName)
          warningUntil = getTime() + 500 -- 5 seconds (tick = 10 ms)
        end
        break
      end

      -- If the model file exists but is invalid, try TEMPLATE and report it.
      if i == 1 then
        usedTemplate = true
      end
    else
      -- Model file not found -> create it from TEMPLATE.lua, then try TEMPLATE next.
      if i == 1 then
        usedTemplate = true
        createModelConfig(modelName)
      end
    end
  end

  if usedTemplate and warningText == nil and cfg == nil then
    warningText = buildNoConfigWarning({ options = currentOptions }, modelName)
    warningUntil = getTime() + 500 -- 5 seconds (tick = 10 ms)
  end

  if type(cfg) == "table" then
    return cfg
  end

  --------------------------------------------------------------------------
  -- Built-in safe default (used only if no external file could be loaded)
  --------------------------------------------------------------------------
  local fallback = { buttons = {} }
  for i=1,16 do
    fallback.buttons[i] = { label=tostring(i), type="toggle" }
  end
  fallback.prop = { label="PROP" }
  return fallback
end

-- --------------------------------------------------------------------------
-- Accès GVars (GV1..GV9) - API EdgeTX : index 0..8 + phase (0)
-- --------------------------------------------------------------------------
local function _getGVar(n, options)
  local fm = getFM(options)
  -- model.getGlobalVariable(gvIndex, flightMode)
  local ok, v = pcall(function() return model.getGlobalVariable(n, fm) end)
  if ok and v ~= nil then return v end
  -- fallback (should not be needed)
  return model.getGlobalVariable(n)
end

local function _setGVar(n, v, options)
  local fm = getFM(options)
  v = v or 0
  local ok = pcall(function() model.setGlobalVariable(n, fm, v) end)
  if not ok then
    -- fallback
    model.setGlobalVariable(n, v)
  end
end

local function _getMask16()
  -- GV1 est une GVar "signée" souvent limitée à [-1024..1024].
  -- Pour stocker 11 bits (0..2047) sans perdre des bits, on stocke dans GV1 un
  -- encodage biaisé : GV1 = lo - 1024  (donc [-1024..1023]).
  local lo_enc = _getGVar(1, currentOptions) or 0
  local lo = lo_enc + 1024
  if lo < 0 then lo = 0 end
  if lo > 2047 then lo = 2047 end

  local hi = _getGVar(2, currentOptions) or 0
  if hi < 0 then hi = 0 end
  if hi > 31 then hi = 31 end

  return lo + hi * 2048
end

local function _setMask16(mask)
  -- Stockage biaisé du bas 11 bits dans GV1 :
  --   lo = mask % 2048 (0..2047)
  --   GV1 = lo - 1024 ([-1024..1023])  -> évite le "clamp" EdgeTX à 1024
  local lo = mask % 2048
  local hi = math.floor(mask / 2048) % 32
  local lo_enc = lo - 1024
  _setGVar(1, lo_enc, currentOptions)
  _setGVar(2, hi, currentOptions)
end

-- gv_get / gv_set : “GV virtuelles” utilisées par l’UI et par xanytx.lua
--   idx 1..16 -> boutons (bits)
--   idx 17    -> PROP
--   idx 18    -> Repeat
--   idx 31    -> CH mémo
--   idx 32    -> MODE
function gv_get(idx, default)
  if idx >= 1 and idx <= 16 then
    local mask = _getMask16()
    local bit = 2^(idx-1)
    return (math.floor(mask / bit) % 2) ~= 0 and 1 or 0
  end
  if idx == 17 then return _getGVar(6, currentOptions) or (default or 0) end
  if idx == 18 then return _getGVar(3, currentOptions) or (default or 0) end
  if idx == 19 then return _getGVar(7, currentOptions) or (default or 0) end
  if idx == 31 then return _getGVar(5, currentOptions) or (default or 0) end
  if idx == 32 then return _getGVar(4, currentOptions) or (default or 0) end
  return default or 0
end

function gv_set(idx, val)
  val = val or 0
  if idx >= 1 and idx <= 16 then
    local mask = _getMask16()
    local bit = 2^(idx-1)
    if val ~= 0 then
      if (math.floor(mask / bit) % 2) == 0 then mask = mask + bit end
    else
      if (math.floor(mask / bit) % 2) == 1 then mask = mask - bit end
    end
    _setMask16(mask)
    return true
  end
  if idx == 17 then _setGVar(6, val, currentOptions); return true end
  if idx == 18 then _setGVar(3, val, currentOptions); return true end
  if idx == 19 then _setGVar(7, val, currentOptions); return true end
  if idx == 31 then _setGVar(5, val, currentOptions); return true end
  if idx == 32 then _setGVar(4, val, currentOptions); return true end
  return false
end

-- --------------------------------------------------------------------------
-- API passée à buttons.lua (évite les globals et clarifie)
-- --------------------------------------------------------------------------
local function makeAPI()
  return {
    gv_get = gv_get,
    gv_set = gv_set,
  }
end

-- --------------------------------------------------------------------------
-- Options widget (EdgeTX)
-- --------------------------------------------------------------------------
local options = {
  { "ID",     VALUE, 1, 1, 4 },                                        -- Instance ID (1..4) mapped to FM0..FM3
  { "MODE",   CHOICE, 1, { "SW8", "SW8+PROP", "SW16", "SW16+PROP", "ANGLE+PROP" } }, -- CHOICE returns 1..5 here
  { "CH",     VALUE, 8, 1, 16 },                                       -- voie (info + confort)
  { "Repeat", VALUE, 0, 0, 6 },                                        -- Repeat (0 = pas de répétition)
  { "OffCol", COLOR, DARKGREEN },                                      -- Couleur OFF
  { "OnCol",  COLOR, GREEN },                                          -- Couleur ON
  { "Shadow", BOOL, 0 },                                               -- Ombres
  { "Language", CHOICE, 0,{ "cn", "de", "en", "fr", "it", "sp"} },     -- Languages
  
}

-- --------------------------------------------------------------------------
-- drawVersionError()
-- If EdgeTX is older than 2.11, the widget is blocked cleanly and displays
-- a blinking red / dark-grey warning.
-- --------------------------------------------------------------------------
local function drawVersionError(wgt)
  local x = wgt.zone.x + math.floor(wgt.zone.w / 2)
  local y = wgt.zone.y + math.floor(wgt.zone.h / 2) - 10

  local blink = math.floor(getTime() / 25) % 2

  local langCode = getLanguageCode(wgt)
  local filePath = "/WIDGETS/XANYCTL/Languages/" .. langCode .. "/Warning_BadVersion.txt"

  local suffix = readTextFile(filePath)
  if not suffix or suffix == "" then
    suffix = "required"
  end

  local msg = "EdgeTX " .. os1 .. "+ " .. suffix

  if blink == 0 then
    lcd.setColor(CUSTOM_COLOR, DARKGREY)
    lcd.drawText(x + 2, y + 2, msg, CUSTOM_COLOR + CENTER + MIDSIZE)

    lcd.setColor(CUSTOM_COLOR, RED)
    lcd.drawText(x, y, msg, CUSTOM_COLOR + CENTER + MIDSIZE)
  else
    lcd.setColor(CUSTOM_COLOR, RED)
    lcd.drawText(x + 2, y + 2, msg, CUSTOM_COLOR + CENTER + MIDSIZE)

    lcd.setColor(CUSTOM_COLOR, DARKGREY)
    lcd.drawText(x, y, msg, CUSTOM_COLOR + CENTER + MIDSIZE)
  end
end

-- --------------------------------------------------------------------------
-- create() : charge config modèle + UI
-- --------------------------------------------------------------------------
local function create(zone, opts)
  local wgt = {
    zone = zone,
    options = opts,
  }

  -- Runtime context used by gv_get/gv_set
  currentOptions = opts

  -- Block widget cleanly if EdgeTX version is too old
  if not EDGE_MIN_OK then
    wgt.versionError = true
    return wgt
  end

  -- Charge la configuration modèle (ou TEMPLATE.lua en fallback)
  local rawCfg = loadModelConfig()
  wgt.config = selectInstanceConfig(rawCfg, opts)

  -- Synchronise MODE / CH / Repeat vers les GVars packées
  local mode = normalizeModeChoice((wgt.options and wgt.options.MODE) or 1)
  local ch   = (wgt.options and wgt.options.CH) or 8
  local rep  = (wgt.options and wgt.options.Repeat) or 0
  gv_set(32, mode)
  gv_set(31, ch)
  gv_set(18, rep)

  -- UI libGUI dans fichier séparé
  local uiChunk = loadScript("/WIDGETS/"..name.."/buttons.lua")
  if uiChunk then
    wgt.ui = uiChunk(zone, opts, wgt.config, makeAPI())
  else
    wgt.ui = nil
  end

  return wgt
end

-- --------------------------------------------------------------------------
-- update() : appelé quand l’utilisateur modifie les options
-- --------------------------------------------------------------------------
local function update(wgt, opts)
  local oldId = (wgt.options and wgt.options.ID) or 1

  wgt.options = opts
  currentOptions = opts

  -- If version is too old, keep the widget blocked.
  if wgt.versionError then
    return
  end

  -- Synchronise MODE / CH / Repeat vers les GVars packées
  local mode = normalizeModeChoice((wgt.options and wgt.options.MODE) or 1)
  local ch   = (wgt.options and wgt.options.CH) or 8
  local rep  = (wgt.options and wgt.options.Repeat) or 0
  gv_set(32, mode)
  gv_set(31, ch)
  gv_set(18, rep)

  -- If ID changed, reload config + rebuild UI so labels update immediately
  if oldId ~= ((opts and opts.ID) or 1) then
    local rawCfg = loadModelConfig()
    wgt.config = selectInstanceConfig(rawCfg, opts)

    local uiChunk = loadScript("/WIDGETS/"..name.."/buttons.lua")
    if uiChunk then
      wgt.ui = uiChunk(wgt.zone, opts, wgt.config, makeAPI())
    else
      wgt.ui = nil
    end
    return
  end

  if wgt.ui and wgt.ui.update then
    wgt.ui.options = opts
    wgt.ui.config = wgt.config
    wgt.ui:update()
  end
end

-- --------------------------------------------------------------------------
-- drawWarning()
-- Centered temporary warning text:
--   - dark grey shadow
--   - red foreground
-- --------------------------------------------------------------------------


local function drawWarning(wgt)
  if not warningText then return false end
  if getTime() >= warningUntil then return false end

  local x = wgt.zone.x + math.floor(wgt.zone.w / 2)
  local y = wgt.zone.y + math.floor(wgt.zone.h / 2) - 20

  local txt = tostring(warningText)
  local pos = string.find(txt, string.char(10), 1, true)

  local l1 = txt
  local l2 = nil

  if pos then
    l1 = string.sub(txt, 1, pos - 1)
    l2 = string.sub(txt, pos + 1)
  end

  lcd.setColor(CUSTOM_COLOR, DARKGREY)
  lcd.drawText(x + 2, y + 2, l1, CUSTOM_COLOR + CENTER + MIDSIZE)

  lcd.setColor(CUSTOM_COLOR, RED)
  lcd.drawText(x, y, l1, CUSTOM_COLOR + CENTER + MIDSIZE)

  -- larger vertical spacing between the two lines
  if l2 and l2 ~= "" then
    lcd.setColor(CUSTOM_COLOR, DARKGREY)
    lcd.drawText(x + 2, y + 42, l2, CUSTOM_COLOR + CENTER + MIDSIZE)

    lcd.setColor(CUSTOM_COLOR, RED)
    lcd.drawText(x, y + 40, l2, CUSTOM_COLOR + CENTER + MIDSIZE)
  end

  return true
end



-- --------------------------------------------------------------------------
-- refresh() : dessin + évènements
-- --------------------------------------------------------------------------
local function refresh(wgt, event, touchState)
  currentOptions = wgt.options
  
  local langCode = getLanguageCode(wgt)
  languagePath = "/WIDGETS/XANYCTL/Languages/" .. langCode .. "/"

  if wgt.versionError then
    drawVersionError(wgt)
    return
  end

  -- Warning overlay displayed for 3 seconds, then normal widget display resumes.
  if drawWarning(wgt) then
    return
  end

  if wgt.ui and wgt.ui.refresh then
    wgt.ui:refresh(event, touchState)
  else
    -- fallback minimal si buttons.lua absent
	local msg = readTextFile(languagePath .. "Warning_NoButtonsFile.txt")
	if not msg or msg == "" then
	  msg = "XANYCTL buttons.lua missing"
	end
	lcd.drawText(wgt.zone.x+2, wgt.zone.y+2, msg, SMLSIZE)
  end
end

local function background(wgt)
  currentOptions = wgt.options
  if wgt.versionError then
    return
  end
  if wgt.ui and wgt.ui.background then
    wgt.ui:background()
  end
end

return {
  name = name,
  create = create,
  refresh = refresh,
  background = background,
  options = options,
  update = update
}
