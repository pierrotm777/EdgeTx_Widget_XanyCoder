-- xanytx2.lua - XANY FM-bank wrapper
-- ID=2 -> FM1
FM_INDEX = 1
return loadScript("/SCRIPTS/MIXES/xanytx_common.lua")()
