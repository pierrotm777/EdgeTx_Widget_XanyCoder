-- MODIF: EdgeTX GV1..GV6 uniquement (pack boutons + repeat/mode/prop). Voir en-tête. 
----------------------------------------------------------------------
----------------------------------------------------------------------
-- xanytx.lua v1.17 (SW8 + checksum + Repeat, conforme Xany/RcTxSerial)  -- MODIF
--
-- OBJECTIF :
--   Encoder les états (8 inters pour SW8) dans UNE seule voie, selon le principe Xany :
--     - data = 8 bits (0..255)
--     - checksum = data XOR 0x55
--     - nibbles RAW = data_hi, data_lo, cks_hi, cks_lo
--     - message délimité par Idle I (17) au début et à la fin
--     - compression RcTxSerial : si deux nibbles RAW consécutifs sont identiques, le 2ème devient R (16)
--     - Repeat : chaque symbole déjà déterminé est répété (Repeat+1) fois (Repeat stocké dans GV3)  -- MODIF
--
-- IMPORTANT (EdgeTX GVars) :
--   EdgeTX = GV1..GV9. Le widget packe tout dans GV1..GV6 :
--     * GV1/GV2 : mask 16 bits boutons (1..16)
--     * GV3     : Repeat (0..6)
--     * GV4     : MODE (0..3)
--     * GV5     : CH mémo (info)
--     * GV6     : PROP (0..255)
----------------------------------------------------------------------

-- Largeur d'impulsion correspondant au nibble 0
-- Xany utilise 1024 µs comme base
local US_BASE = 1024

-- Pas entre deux nibbles
-- 1 nibble = +56 µs
local US_STEP = 56

-- Neutre radio standard
local US_NEUT = 1500

-- Amplitude totale entre neutre et extrémité canal
-- IMPORTANT :
--   +/-114%  ˜ 570 µs
--   +/-116%  ˜ 580 µs
--   +/-125%  = 625 µs
--
-- Ajuster selon tes limites CH8
local FULL_EXCURSION_US = 510  -- MODIF: mode ±100% (1000..2000µs)

-- MODIF v1.16b:
--  - US_IDLE_US permet d'ajuster finement l'impulsion Idle si besoin (en µs).
--    Par défaut: 1024 + 56*17 = 1976 µs.
--    Si tu mesures I trop haut/bas, ajuste par pas de 4 ou 8 µs.
local US_IDLE_US = (US_BASE + US_STEP * 17) - 4 -- baisse I de 4µs (évite les 1980)

-- MODIF: compatibilité bitwise EdgeTX/OpenTX (pas d'opérateurs & | ~ << >>)
-- - Si bit32 est dispo: on l'utilise.
-- - Sinon: on émule en arithmétique (32-bit non signé).
local _bit = bit32  -- peut être nil suivant le build

local function _u32(x)
  x = math.floor(tonumber(x) or 0)
  x = x % 4294967296
  return x
end

local function _band(a, b)
  if _bit then return _bit.band(a, b) end
  a = _u32(a); b = _u32(b)
  local res, bit = 0, 1
  for _ = 1, 32 do
    local aa = a % 2
    local bb = b % 2
    if aa == 1 and bb == 1 then res = res + bit end
    a = (a - aa) / 2
    b = (b - bb) / 2
    bit = bit * 2
  end
  return res
end

local function _bor(a, b)
  if _bit then return _bit.bor(a, b) end
  a = _u32(a); b = _u32(b)
  local res, bit = 0, 1
  for _ = 1, 32 do
    local aa = a % 2
    local bb = b % 2
    if aa == 1 or bb == 1 then res = res + bit end
    a = (a - aa) / 2
    b = (b - bb) / 2
    bit = bit * 2
  end
  return res
end

local function _bxor(a, b)
  if _bit then return _bit.bxor(a, b) end
  a = _u32(a); b = _u32(b)
  local res, bit = 0, 1
  for _ = 1, 32 do
    local aa = a % 2
    local bb = b % 2
    if aa ~= bb then res = res + bit end
    a = (a - aa) / 2
    b = (b - bb) / 2
    bit = bit * 2
  end
  return res
end

local function _lsh(a, n)
  if _bit then return _bit.lshift(a, n) end
  return _u32(_u32(a) * (2 ^ (tonumber(n) or 0)))
end

local function _rsh(a, n)
  if _bit then return _bit.rshift(a, n) end
  return math.floor(_u32(a) / (2 ^ (tonumber(n) or 0)))
end

local function _bnot(a)
  if _bit then return _bit.bnot(a) end
  return 4294967295 - _u32(a)
end

----------------------------------------------------------------------
-- clamp(x, lo, hi)
-- Limite une valeur dans un intervalle
-- Utilisé pour éviter de dépasser -1024 / +1024 côté EdgeTX
----------------------------------------------------------------------
local function clamp(x, lo, hi)
  if x < lo then return lo end
  if x > hi then return hi end
  return x
end


----------------------------------------------------------------------
-- us_to_etx(us)
--
-- Convertit une largeur d'impulsion (µs)
-- en valeur mix EdgeTX (-1024..+1024)
--
-- Relation utilisée :
--   us = 1500 + value * FULL_EXCURSION_US / 1024
--
-- Donc :
--   value = (us - 1500) * 1024 / FULL_EXCURSION_US
--
----------------------------------------------------------------------
local function us_to_etx(us)
  local v = (us - US_NEUT) * 1024 / FULL_EXCURSION_US
  return clamp(v, -1024, 1024)
end


----------------------------------------------------------------------
-- nibble_to_etx(n)
--
-- Convertit un nibble Xany (0..15 ou 17=I)
-- en valeur EdgeTX correspondante
--
-- Largeur calculée :
--   us = US_BASE + US_STEP * n
--
-- Puis conversion en valeur radio.
----------------------------------------------------------------------
local function nibble_to_etx(n)
  -- Convertit un nibble Xany (0..15) ou Idle (I=17) en valeur EdgeTX.
  -- MODIF v1.16c:
  --  - On utilise US_IDLE_US pour que l'Idle soit au plus près de 1976µs.
  if n == NIBBLE_I then
    -- Idle = nibble 17
    return us_to_etx(US_IDLE_US)  -- MODIF v1.16b: idle ajustable
  else
    return us_to_etx(US_BASE + US_STEP * n)
  end
end


----------------------------------------------------------------------
----------------------------------------------------------------------
-- TRAME DYNAMIQUE SW8 (data + checksum)
--
-- Le widget fournit 16 boutons, mais en mode SW8 on utilise seulement les 8 premiers (bits 1..8).
-- data = b1..b8 (b1 = LSB)
-- checksum = data XOR 0x55
--
-- nibbles RAW à transmettre : data_hi, data_lo, cks_hi, cks_lo
-- message final : I, (raw1..raw4 compressés par R si doublon), I
----------------------------------------------------------------------
local NIBBLE_I = 17
local NIBBLE_R = 16

-- Accès GVars réelles (GV1..GV6)
local function gvarGet(gvnum, def)
  local idx = (gvnum or 1) - 1
  local v = nil
  if model and model.getGlobalVariable then
    v = model.getGlobalVariable(idx, 0)
  elseif getGlobalVariable then
    v = getGlobalVariable(idx, 0)
  end
  if v == nil then return def end
  return v
end

-- mask 16 bits boutons depuis GV1/GV2 (pack)
local function getMask16()
  -- IMPORTANT (widget pack GVars) :
  --   GV1 contient le bas 11 bits (0..2047) mais stocké en biaisé :
  --     GV1 = lo - 1024  -> plage [-1024..1023]
  --   GV2 contient les 5 bits hauts (0..31)
  local lo_enc = gvarGet(1, 0) or 0
  local lo = lo_enc + 1024
  if lo < 0 then lo = 0 end
  if lo > 2047 then lo = 2047 end

  local hi = gvarGet(2, 0) or 0
  if hi < 0 then hi = 0 end
  if hi > 31 then hi = 31 end

  return lo + hi * 2048
end
-- Repeat depuis GV3 (0..6)
local function getRepeat()
  local r = gvarGet(3, 0) or 0
  if r < 0 then r = 0 end
  if r > 6 then r = 6 end
  return r
end

-- ----------------------------------------------------------------------
-- build_payload_and_checksum(mode)
--
-- Construit la liste d'octets "data" selon le MODE choisi par le widget,
-- puis calcule le checksum Xany :
--   checksum = XOR( tous les octets de data ) XOR 0x55
--
-- MODE (GV4) :
--   0 = SW8
--   1 = SW8 + PROP
--   2 = SW16
--   3 = SW16 + PROP
--
-- GVars (réelles) utilisées :
--   GV1 + GV2 : mask 16 bits (boutons 1..16)
--   GV6       : PROP (0..255) (uniquement utile en modes +PROP)
-- ----------------------------------------------------------------------
local function build_payload_and_checksum(mode)
  local mask = getMask16()

  -- Octets data[] construits selon le mode
  local data = {}

  if mode == 0 or mode == 1 then
    -- SW8 : seulement boutons 1..8 (LSB = bouton 1)
    data[1] = _band(mask, 0xFF)
  else
    -- SW16 : boutons 1..16
    -- ATTENTION ordre octets SW16 :
    -- Certains décodeurs Xany attendent d'abord l'octet HAUT (boutons 9..16),
    -- puis l'octet BAS (boutons 1..8). Si tu observes une inversion 1..8 <-> 9..16,
    -- c'est ici qu'il faut permuter.
    data[1] = _band(_rsh(mask, 8), 0xFF)        -- high byte (boutons 9..16)
    data[2] = _band(mask, 0xFF)                 -- low byte  (boutons 1..8)
  end

  if mode == 1 or mode == 3 then
    -- +PROP : ajoute l'octet PROP
    local prop = gvarGet(6, 0) or 0
    if prop < 0 then prop = 0 end
    if prop > 255 then prop = 255 end
    data[#data + 1] = _band(prop, 0xFF)
  end

  -- Checksum = XOR(data bytes) XOR 0x55
  local cks = 0
  for i = 1, #data do
    cks = _bxor(cks, _band(data[i], 0xFF))
  end
  cks = _bxor(cks, 0x55)
  cks = _band(cks, 0xFF)

  return data, cks
end

-- ----------------------------------------------------------------------
-- build_raw_nibbles()
--
-- Construit la liste des nibbles RAW à transmettre (SANS les Idle I de début/fin).
-- Ordre demandé :
--   SW8        : dhi, dlo, chi, clo
--   SW16       : d0hi, d0lo, d1hi, d1lo, chi, clo
--   SW8+PROP   : d0hi, d0lo, p0hi, p0lo, chi, clo
--   SW16+PROP  : d0hi, d0lo, d1hi, d1lo, p0hi, p0lo, chi, clo
-- ----------------------------------------------------------------------
local function build_raw_nibbles()
  local mode = gvarGet(4, 0) or 0
  if mode < 0 then mode = 0 end
  if mode > 3 then mode = 3 end

  local data, cks = build_payload_and_checksum(mode)

  local raw = {}

  -- Data nibbles (hi,lo) pour chaque octet
  for i = 1, #data do
    local b = _band(data[i], 0xFF)
    raw[#raw + 1] = _band(_rsh(b, 4), 0x0F)
    raw[#raw + 1] = _band(b, 0x0F)
  end

  -- Checksum nibbles (hi,lo)
  raw[#raw + 1] = _band(_rsh(cks, 4), 0x0F)
  raw[#raw + 1] = _band(cks, 0x0F)

  return raw
end

-- ----------------------------------------------------------------------
-- Variables d'état (machine d'émission)
--
-- On émet une trame :
--   I, RAW..., I
--
-- Compression "R" :
--   - appliquée UNIQUEMENT sur les nibbles RAW consécutifs (pas sur I)
--   - si deux nibbles RAW consécutifs sont identiques, le 2ème devient R (16)
--
-- Repeat (GV3) :
--   - répète le symbole déjà déterminé (RAW ou R) (Repeat+1) fois
-- ----------------------------------------------------------------------
local raw = {}         -- nibbles RAW (sans I)
local rawPos = 0       -- 0 = on va émettre I de début, 1..#raw = RAW, #raw+1 = I de fin
local lastT = 0
local stepEvery = 2    -- 20ms par symbole (tick=10ms)

local lastRaw = -1     -- dernier nibble RAW (pour compression R)
local lastWasR = false -- MODIF v1.3: évite 'R R R' sur longues répétitions (stabilise tout-off)
local txSym = nil      -- symbole réellement envoyé (RAW ou R ou I)
local repeatCnt = 0    -- compteur de répétition du txSym

-- Repeat \"par trame\" (option B): réémet la trame complète I..RAW..I, sans allonger la trame.
-- Avantage: compatible décodeurs à longueur stricte (XanySpy/RcRxSerial).
local frameRepLeft = 0    -- nb de réémissions restantes pour la trame courante
local reuseFrame = false  -- true => renvoyer le même RAW sans recalcul \(GVars gelées\)
local interIdleLeft = 0   -- nb de symboles Idle à insérer entre deux trames répétées (stabilité décodeur)
local INTER_IDLE_SYMS = 2 -- MODIF: 2 Idles entre trames répétées (ne change pas la longueur payload)

local function init()
  raw = {}
  rawPos = 0
  lastRaw = -1

      lastWasR = false  -- MODIF v1.3
  lastWasR = false  -- MODIF v1.3
  lastWasR = false  -- MODIF v1.3
  -- MODIF v1.2: cadence symbole adaptée quand Repeat>0
  -- Beaucoup de récepteurs sortent la PWM autour de 18ms (≈55Hz). Si on change de symbole
  -- toutes les 20ms (tick=2), le décodeur (RcRxSerial + filtrage) peut voir des transitions
  -- "trop rapides" et perdre la synchro, surtout sur des trames longues (SW16).
  -- => Quand Repeat est actif, on ralentit volontairement la cadence symbole:
  --    - SW8 / SW8+PROP : 30ms (stepEvery=3)
  --    - SW16 / SW16+PROP : 40ms (stepEvery=4)
  --    - Repeat=0 : on conserve 20ms (stepEvery=2) comme avant.
  local mode = gvarGet(4, 0) or 0
  if mode < 0 then mode = 0 end
  if mode > 3 then mode = 3 end
  local rep = getRepeat() or 0
  if rep > 0 then
    if mode >= 2 then
      stepEvery = 4
    else
      stepEvery = 3
    end
  else
    stepEvery = 2
  end
  txSym = nil
  repeatCnt = 0
  lastT = getTime()
end

-- Recalcule la trame au début de chaque message (juste avant I de début)
local function refresh_frame()
  raw = build_raw_nibbles()
  rawPos = 0
  lastRaw = -1

  -- Option B: Repeat \"par trame\". On gèle le payload au début de la trame,
  -- puis on réémet exactement la même trame frameRepLeft fois après l'Idle de fin.
  frameRepLeft = getRepeat() or 0
  reuseFrame = false
  interIdleLeft = 0
end

local function run()
  local now = getTime()

  -- Resync si gros trou (radio en attente, etc.)
  if lastT ~= 0 and (now - lastT) > (stepEvery * 12) then
    rawPos = 0
    lastRaw = -1
    txSym = nil
    lastWasR = false  -- MODIF v1.3
    repeatCnt = 0
    lastT = now
    frameRepLeft = 0
    reuseFrame = false
    interIdleLeft = 0
  end

  -- Tant que l'intervalle n'est pas atteint, on maintient le dernier symbole
  if (now - lastT) < stepEvery then
    return nibble_to_etx(txSym or NIBBLE_I)
  end
  lastT = now
  -- Option B (Repeat par trame): pas de répétition "symbole par symbole" ici.
  -- La trame complète sera réémise après l'Idle de fin (voir plus bas).
  -- Début d'un nouveau message : on (re)calcule RAW avant d'envoyer le I de début
  if rawPos == 0 then
    -- MODIF: entre deux trames répétées, on insère quelques Idles pour fiabiliser le décodeur.
    if interIdleLeft > 0 then
      interIdleLeft = interIdleLeft - 1
      txSym = NIBBLE_I
      return nibble_to_etx(txSym)
    end
    -- Début de trame: on ne recalcule RAW que si on n'est pas en réémission.
    if not reuseFrame then
      refresh_frame()
    else
      -- Réémission: on garde le même RAW (GVars gelées sur la trame précédente).
      reuseFrame = false
      rawPos = 0
      lastRaw = -1
    end
    txSym = NIBBLE_I
    rawPos = 1
    return nibble_to_etx(txSym)
  end

  -- Emission des RAW (compression R uniquement sur RAW)
  if rawPos >= 1 and rawPos <= #raw then
    local r = raw[rawPos]

    -- MODIF v1.3:
    --   La règle X-Any est "A A -> A R" (compression par paires).
    --   Sur une longue suite identique (ex: 0 0 0 0), il faut obtenir :
    --     0 R 0 R
    --   et non :
    --     0 R R R
    --   Car des symboles identiques consécutifs (R R) deviennent invisibles sur une sortie PWM (~18ms)
    --   et le décodeur peut "perdre des nibbles", surtout quand tous les boutons sont OFF.
    if r == lastRaw then
      if lastWasR then
        txSym = r          -- alterne: ... R, puis RAW
        lastWasR = false
      else
        txSym = NIBBLE_R   -- alterne: RAW, puis R
        lastWasR = true
      end
    else
      txSym = r
      lastWasR = false
    end

    lastRaw = r
    rawPos = rawPos + 1
    return nibble_to_etx(txSym)
  end

  -- Fin de message : I de fin.
  txSym = NIBBLE_I

  -- Option B (Repeat par trame): après l'Idle de fin, on réémet la même trame complète.
  if frameRepLeft > 0 then
    frameRepLeft = frameRepLeft - 1
    reuseFrame = true
    interIdleLeft = INTER_IDLE_SYMS  -- MODIF: insère des Idles avant la trame suivante
  end

  rawPos = 0
  lastRaw = -1
  lastWasR = false  -- MODIF v1.3
  return nibble_to_etx(txSym)
end
return {
  input = {},
  output = { "XANY" },
  run = run,
  init = init
}