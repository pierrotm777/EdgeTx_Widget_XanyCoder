-- XANYCTL - Widget principal
-- EdgeTX 2.11+ / TX16S (tactile)
--
-- Objectif actuel :
--   - SW8 / SW8+PROP / SW16 / SW16+PROP
--   - trame X-Any générée côté MIXES/xanytx.lua (script de mix)
--   - le widget ne fait que piloter des "GV virtuelles" packées dans GV1..GV6
--
-- PACK GVars (vrai modèle EdgeTX : GV1..GV9 max) :
--   GV1 + GV2 : mask 16 bits (boutons 1..16)
--              GV1 = partie basse (0..2047)
--              GV2 = partie haute (0..31) -> mask = GV1 + GV2*2048
--   GV3       : Repeat (0..6)  (Repeat+1 symboles identiques si besoin)
--   GV4       : MODE (0=SW8, 1=SW8+PROP, 2=SW16, 3=SW16+PROP)
--   GV5       : CH mémo (info confort ; la vraie voie est celle où tu mixes la sortie LUA)
--   GV6       : PROP (0..255) (utilisé uniquement en modes +PROP)
--
-- IMPORTANT :
--   - Dans un WIDGET, EdgeTX ne fournit pas gv_get/gv_set globalement.
--     On fournit ici des wrappers compatibles via model.getGlobalVariable()/setGlobalVariable().
--   - Les accents sont en UTF-8 (é, è, à…).

local name = "XANYCTL"

-- --------------------------------------------------------------------------
-- Chargement config par modèle (fichier à côté du widget)
--   Exemple : /WIDGETS/XANYCTL/MODEL011.lua
--   ou bien /WIDGETS/XANYCTL/<NomDuModele>.lua (nom exact EdgeTX)
-- --------------------------------------------------------------------------
local function loadModelConfig()
  local mi = model.getInfo()
  local try = {
    "/WIDGETS/"..name.."/"..(mi and mi.name or "MODEL")..".lua",
    "/WIDGETS/"..name.."/MODEL"..string.format("%03d", mi and mi.id or 0)..".lua",
  }
  for _, p in ipairs(try) do
    local chunk = loadScript(p)
    if chunk then
      local ok, cfg = pcall(chunk)
      if ok and type(cfg) == "table" then
        return cfg
      elseif ok and type(cfg) == "function" then
        local ok2, cfg2 = pcall(cfg)
        if ok2 and type(cfg2) == "table" then return cfg2 end
      end
    end
  end
  -- config par défaut (labels 1..16 toggle)
  local cfg = { buttons = {} }
  for i=1,16 do cfg.buttons[i] = { label=tostring(i), type="toggle" } end
  cfg.prop = { label="PROP" }
  return cfg
end

-- --------------------------------------------------------------------------
-- Accès GVars (GV1..GV9) - API EdgeTX : index 0..8 + phase (0)
-- --------------------------------------------------------------------------
local function _getGVar(n)
  return model.getGlobalVariable(n-1, 0)
end

local function _setGVar(n, v)
  model.setGlobalVariable(n-1, 0, v)
end

local function _getMask16()
  -- GV1 est une GVar "signée" souvent limitée à [-1024..1024].
  -- Pour stocker 11 bits (0..2047) sans perdre des bits, on stocke dans GV1 un
  -- encodage biaisé : GV1 = lo - 1024  (donc [-1024..1023]).
  local lo_enc = _getGVar(1) or 0
  local lo = lo_enc + 1024
  if lo < 0 then lo = 0 end
  if lo > 2047 then lo = 2047 end

  local hi = _getGVar(2) or 0
  if hi < 0 then hi = 0 end
  if hi > 31 then hi = 31 end

  return lo + hi * 2048
end
local function _setMask16(mask)
  -- Stockage biaisé du bas 11 bits dans GV1 :
  --   lo = mask % 2048 (0..2047)
  --   GV1 = lo - 1024 ([-1024..1023])  -> évite le "clamp" EdgeTX à 1024
  local lo = mask % 2048
  local hi = math.floor(mask / 2048) % 32
  local lo_enc = lo - 1024
  _setGVar(1, lo_enc)
  _setGVar(2, hi)
end
-- gv_get / gv_set : “GV virtuelles” utilisées par l’UI et par xanytx.lua
--   idx 1..16 -> boutons (bits)
--   idx 17    -> PROP
--   idx 18    -> Repeat
--   idx 31    -> CH mémo
--   idx 32    -> MODE
function gv_get(idx, default)
  if idx >= 1 and idx <= 16 then
    local mask = _getMask16()
    local bit = 2^(idx-1)
    return (math.floor(mask / bit) % 2) ~= 0 and 1 or 0
  end
  if idx == 17 then return _getGVar(6) or (default or 0) end
  if idx == 18 then return _getGVar(3) or (default or 0) end
  if idx == 31 then return _getGVar(5) or (default or 0) end
  if idx == 32 then return _getGVar(4) or (default or 0) end
  return default or 0
end

function gv_set(idx, val)
  val = val or 0
  if idx >= 1 and idx <= 16 then
    local mask = _getMask16()
    local bit = 2^(idx-1)
    if val ~= 0 then
      if (math.floor(mask / bit) % 2) == 0 then mask = mask + bit end
    else
      if (math.floor(mask / bit) % 2) == 1 then mask = mask - bit end
    end
    _setMask16(mask)
    return true
  end
  if idx == 17 then _setGVar(6, val); return true end
  if idx == 18 then _setGVar(3, val); return true end
  if idx == 31 then _setGVar(5, val); return true end
  if idx == 32 then _setGVar(4, val); return true end
  return false
end

-- --------------------------------------------------------------------------
-- API passée à buttons.lua (évite les globals et clarifie)
-- --------------------------------------------------------------------------
local function makeAPI()
  return {
    gv_get = gv_get,
    gv_set = gv_set,
  }
end

-- --------------------------------------------------------------------------
-- Options widget (EdgeTX)
-- --------------------------------------------------------------------------
local options = {
  { "MODE",   VALUE, 0, 0, 3 },   -- 0=SW8,1=SW8+PROP,2=SW16,3=SW16+PROP
  { "CH",     VALUE, 8, 1, 16 },  -- voie (info + confort)
  { "Repeat", VALUE, 0, 0, 6 },   -- Repeat (0 = pas de répétition)
  { "OffCol", COLOR, DARKGREEN },  -- Couleur OFF
  { "OnCol", COLOR, GREEN },  -- Couleur ON
  { "Shadow", BOOL, 0 },  -- Ombres
}

-- --------------------------------------------------------------------------
-- create() : charge config modèle + UI
-- --------------------------------------------------------------------------
local function create(zone, opts)
  local wgt = {
    zone = zone,
    options = opts,
    config = loadModelConfig(),
  }

  -- Synchronise MODE / CH / Repeat vers les GVars packées
  local mode = (wgt.options and wgt.options.MODE) or 0
  local ch   = (wgt.options and wgt.options.CH) or 8
  local rep  = (wgt.options and wgt.options.Repeat) or 0
  gv_set(32, mode)
  gv_set(31, ch)
  gv_set(18, rep)

  -- UI libGUI dans fichier séparé
  local uiChunk = loadScript("/WIDGETS/"..name.."/buttons.lua")
  if uiChunk then
    wgt.ui = uiChunk(zone, opts, wgt.config, makeAPI())
  else
    wgt.ui = nil
  end

  return wgt
end

-- --------------------------------------------------------------------------
-- update() : appelé quand l’utilisateur modifie les options
-- --------------------------------------------------------------------------
local function update(wgt, opts)
  wgt.options = opts

  local mode = (wgt.options and wgt.options.MODE) or 0
  local ch   = (wgt.options and wgt.options.CH) or 8
  local rep  = (wgt.options and wgt.options.Repeat) or 0
  gv_set(32, mode)
  gv_set(31, ch)
  gv_set(18, rep)

  if wgt.ui and wgt.ui.update then
    wgt.ui.options = opts
    wgt.ui:update()
  end
end

-- --------------------------------------------------------------------------
-- refresh() : dessin + évènements
-- --------------------------------------------------------------------------
local function refresh(wgt, event, touchState)
  if wgt.ui and wgt.ui.refresh then
    wgt.ui:refresh(event, touchState)
  else
    -- fallback minimal si buttons.lua absent
    lcd.drawText(wgt.zone.x+2, wgt.zone.y+2, "XANYCTL (buttons.lua manquant)", SMLSIZE)
  end
end

local function background(wgt)
  if wgt.ui and wgt.ui.background then
    wgt.ui:background()
  end
end

return {
  name = name,
  create = create,
  refresh = refresh,
  background = background,
  options = options,
  update = update
}
